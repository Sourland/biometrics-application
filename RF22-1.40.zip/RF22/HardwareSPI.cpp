// HardwareSPI.h
// Author: Mike McCauley (mikem@airspayce.com)
// Copyright (C) 2011 Mike McCauley
// Contributed by Joanna Rutkowska
// $Id: HardwareSPI.cpp,v 1.1 2014/04/01 05:06:44 mikem Exp mikem $

#include "HardwareSPI.h"

// Declare a single instance of the hardware SPI interface class
HardwareSPIClass Hardware_spi;
